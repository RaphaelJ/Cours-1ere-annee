#ifndef _TYPES_H
#define _TYPES_H 1

#include <time.h>

typedef char bool;
enum { false, true };

typedef unsigned char byte;

#endif
